
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as s}from"./index.d7acb132.js";import{_ as e}from"./index.6d456c03.js";import{_ as o}from"./plugin-vue_export-helper.5a098b48.js";import{r as t,l as a,H as l,s as n,n as r,I as d,S as i}from"./vendor.1e0be253.js";const u={methods:{close(){this.$tabbar.close("/dashboard")}}},c=d("p",null,"访问侧边栏导航里的任意路由，都会在标签栏里自动创建一个标签。",-1),p=d("p",null,"除了在标签栏里操作关闭标签，你也可以使用全局方法关闭当前页面的标签。但如果当前只有一个标签时，则无法关闭。",-1),m=i("关闭当前标签页");var f=o(u,[["render",function(o,d,i,u,f,b){const _=s,h=t("el-button"),j=e;return a(),l("div",null,[n(_,{title:"标签栏",content:"功能类似于浏览器的标签栏，支持右键操作"}),n(j,null,{default:r((()=>[c,p,n(h,{onClick:b.close},{default:r((()=>[m])),_:1},8,["onClick"])])),_:1})])}]]);export{f as default};
