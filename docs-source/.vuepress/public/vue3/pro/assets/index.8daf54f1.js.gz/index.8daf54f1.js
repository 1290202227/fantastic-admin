
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as e}from"./index.bf374722.js";import{_ as a}from"./plugin-vue_export-helper.5a098b48.js";import{r,l as t,m as o,n as s,S as n,P as i,I as l,L as d,Z as p}from"./vendor.1e0be253.js";const c={class:"num"},u={class:"tip"};var m=a({props:{colorFrom:{type:String,default:"#843cf6"},colorTo:{type:String,default:"#759bff"},header:{type:String,default:""},num:{type:Number,default:0},tip:{type:String,default:""},icon:{type:String,default:""}},setup:a=>(m,f)=>{const g=e,y=r("el-card");return t(),o(y,{shadow:"hover",class:"mini-card",style:p({background:`linear-gradient(50deg, ${a.colorFrom}, ${a.colorTo})`})},{header:s((()=>[n(i(a.header),1)])),default:s((()=>[l("div",c,i(a.num),1),l("div",u,i(a.tip),1),a.icon?(t(),o(g,{key:0,name:a.icon,rotate:20},null,8,["name"])):d("v-if",!0)])),_:1},8,["style"])}},[["__scopeId","data-v-35c54a03"]]);export{m as _};
