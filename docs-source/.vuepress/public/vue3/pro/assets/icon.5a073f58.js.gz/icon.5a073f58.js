
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as g}from"./index.70fd940b.js";import{_ as j}from"./index.3e3f69e0.js";import{_ as b}from"./index.fce7b427.js";import y from"./alert.c49d25d3.js";import{r as o,m as c,Q as s,t as e,q as n,s as t,an as k,a3 as E,a2 as I,Y as $,J as B}from"./vendor.3faf3917.js";import{h as r}from"./index.0dc2fa6b.js";import{_ as C}from"./plugin-vue_export-helper.5a098b48.js";const N=$(" \u641C\u7D22 "),V={setup(q){const i=Object.keys(B);return(w,A)=>{const p=b,m=o("el-icon-edit"),_=o("el-icon"),d=o("el-icon-share"),u=o("el-icon-delete"),f=o("el-button"),a=j,h=g,v=o("el-tooltip");return c(),s("div",null,[e(y),e(p,{title:"\u56FE\u6807"}),e(a,{class:"demo"},{default:n(()=>[e(_,null,{default:n(()=>[e(m)]),_:1}),e(_,null,{default:n(()=>[e(d)]),_:1}),e(_,null,{default:n(()=>[e(u)]),_:1}),e(f,{type:"primary",icon:t(k)},{default:n(()=>[N]),_:1},8,["icon"])]),_:1}),e(a,{title:"\u56FE\u6807\u96C6\u5408"},{default:n(()=>[(c(!0),s(E,null,I(t(i),(l,x)=>(c(),s("div",{key:x,class:"list-icon"},[e(v,{class:"item",effect:"dark",content:t(r)(`ElIcon${l}`),placement:"top"},{default:n(()=>[e(h,{name:t(r)(`ElIcon${l}`)},null,8,["name"])]),_:2},1032,["content"])]))),128))]),_:1})])}}};var Y=C(V,[["__scopeId","data-v-647aef8f"]]);export{Y as default};
