
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as r}from"./index.2f96f609.js";import{_ as c}from"./index.871bab51.js";import{_ as i}from"./index.85eeb4f0.js";import{_ as p}from"./plugin-vue_export-helper.5a098b48.js";import{r as d,l as u,J as m,s as e,n as t,U as o,K as s}from"./vendor.66600095.js";const f={},h=o("\u8FD4\u56DE\u5217\u8868"),x=o("\u6253\u5370"),v=s("div",null,"\u60A8\u63D0\u4EA4\u7684\u5185\u5BB9\u6709\u5982\u4E0B\u9519\u8BEF\uFF1A",-1),b=s("div",null,[o(" \u60A8\u7684\u8D26\u6237\u5DF2\u88AB\u51BB\u7ED3 "),s("a",{href:"###"},"\u6253\u5370")],-1),g=o("\u8FD4\u56DE\u4FEE\u6539");function y(j,z){const a=r,n=d("el-button"),_=c,l=i;return u(),m("div",null,[e(a,{title:"\u5904\u7406\u7ED3\u679C",content:"Result"}),e(l,null,{default:t(()=>[e(_,{type:"success",title:"\u63D0\u4EA4\u6210\u529F",desc:"\u63D0\u4EA4\u7ED3\u679C\u9875\u7528\u4E8E\u53CD\u9988\u4E00\u7CFB\u5217\u64CD\u4F5C\u4EFB\u52A1\u7684\u5904\u7406\u7ED3\u679C\u3002"},{default:t(()=>[e(n,{type:"primary",size:"small"},{default:t(()=>[h]),_:1}),e(n,{size:"small"},{default:t(()=>[x]),_:1})]),_:1})]),_:1}),e(l,null,{default:t(()=>[e(_,{type:"error",title:"\u63D0\u4EA4\u5931\u8D25",desc:"\u7070\u8272\u989D\u5916\u533A\u57DF\u53EF\u4EE5\u663E\u793A\u4E00\u4E9B\u8865\u5145\u7684\u4FE1\u606F\u3002\u8BF7\u6838\u5BF9\u5E76\u4FEE\u6539\u4EE5\u4E0B\u4FE1\u606F\u540E\uFF0C\u518D\u91CD\u65B0\u63D0\u4EA4\u3002"},{extra:t(()=>[v,b]),default:t(()=>[e(n,{type:"primary",size:"small"},{default:t(()=>[g]),_:1})]),_:1})]),_:1})])}var w=p(f,[["render",y]]);export{w as default};
