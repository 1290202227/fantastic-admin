
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as i}from"./index.3e3f69e0.js";import{_ as c}from"./index.fce7b427.js";import{_ as p}from"./plugin-vue_export-helper.5a098b48.js";import{m as d,Q as l,t as _,q as a,_ as r,$ as m,R as t}from"./vendor.3faf3917.js";const f={},e=o=>(r("data-v-302b1ab8"),o=o(),m(),o),u=e(()=>t("p",null,"\u81EA\u5B9A\u4E49\u5B57\u4F53\u9700\u8981\u4E0B\u8F7D\u5B57\u4F53\u6587\u4EF6\uFF0C\u4E0D\u5EFA\u8BAE\u5728\u975E\u82F1\u6587\u73AF\u5883\u4E2D\u4F7F\u7528",-1)),g=e(()=>t("p",{style:{"margin-bottom":"0"}},"\u4EE5\u4E0B\u4E3A\u6846\u67B6\u9884\u8BBE\u5B57\u4F53",-1)),h=e(()=>t("p",{class:"digital-7"},"Fantastic-admin",-1)),v=e(()=>t("p",{class:"digital-7"},"1234567890,.",-1)),x=e(()=>t("p",{class:"digital-7_mono"},"Fantastic-admin",-1)),b=e(()=>t("p",{class:"digital-7_mono"},"1234567890,.",-1));function j(o,I){const n=c,s=i;return d(),l("div",null,[_(n,{title:"\u81EA\u5B9A\u4E49\u5B57\u4F53"},{content:a(()=>[u,g]),_:1}),_(s,{title:"Digital 7"},{default:a(()=>[h,v]),_:1}),_(s,{title:"Digital 7\uFF08\u7B49\u5BBD\uFF09"},{default:a(()=>[x,b]),_:1})])}var w=p(f,[["render",j],["__scopeId","data-v-302b1ab8"]]);export{w as default};
