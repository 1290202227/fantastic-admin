
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a}from"./index.9fbc5cc3.js";import{_ as n}from"./index.5a1a2157.js";import{_ as e}from"./index.c535d87f.js";import{_ as o}from"./plugin-vue_export-helper.5a098b48.js";import{r as i,l as s,H as d,s as l,n as r,S as t}from"./vendor.e59ac5d6.js";const m={methods:{open(a){window.open(a,"top")}}},g=t("SVG-Loaders 官网");var c=o(m,[["render",function(o,t,m,c,p,f){const u=i("el-button"),_=a,v=n,b=e;return s(),d("div",null,[l(_,{title:"SVG 动画",content:"svg 文件从 SVG-Loaders 中提取，需要注意，svg 均为白色，需要增加底色才能看到效果。如需封装成加载组件，可参考 SpinkitLoading 组件"},{default:r((()=>[l(u,{icon:"el-icon-link",onClick:t[0]||(t[0]=a=>f.open("http://samherbert.net/svg-loaders/"))},{default:r((()=>[g])),_:1})])),_:1}),l(b,{style:{"background-color":"#34495e"}},{default:r((()=>[l(v,{name:"loading-audio"}),l(v,{name:"loading-ball-triangle"}),l(v,{name:"loading-bars"}),l(v,{name:"loading-circles"}),l(v,{name:"loading-grid"}),l(v,{name:"loading-hearts"}),l(v,{name:"loading-oval"}),l(v,{name:"loading-puff"}),l(v,{name:"loading-rings"}),l(v,{name:"loading-spinning-circles"}),l(v,{name:"loading-tail-spin"}),l(v,{name:"loading-three-dots"})])),_:1})])}],["__scopeId","data-v-22e7efe2"]]);export{c as default};
