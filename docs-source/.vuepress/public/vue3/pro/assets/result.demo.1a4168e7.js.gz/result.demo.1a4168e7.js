
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as e}from"./index.ffbd20e5.js";import{_ as t}from"./index.3e0ea203.js";import{_ as l}from"./index.f03e52fd.js";import{r as s,l as a,J as r,s as d,n as i,R as n,K as f}from"./vendor.7707186e.js";const u={},o=n("返回列表"),m=n("打印"),p=f("div",null,"您提交的内容有如下错误：",-1),_=f("div",null,[n(" 您的账户已被冻结 "),f("a",{href:"###"},"打印")],-1),c=n("返回修改");u.render=function(n,f){const u=e,y=s("el-button"),x=t,j=l;return a(),r("div",null,[d(u,{title:"处理结果",content:"Result"}),d(j,null,{default:i((()=>[d(x,{type:"success",title:"提交成功",desc:"提交结果页用于反馈一系列操作任务的处理结果。"},{default:i((()=>[d(y,{type:"primary",size:"small"},{default:i((()=>[o])),_:1}),d(y,{size:"small"},{default:i((()=>[m])),_:1})])),_:1})])),_:1}),d(j,null,{default:i((()=>[d(x,{type:"error",title:"提交失败",desc:"灰色额外区域可以显示一些补充的信息。请核对并修改以下信息后，再重新提交。"},{extra:i((()=>[p,_])),default:i((()=>[d(y,{type:"primary",size:"small"},{default:i((()=>[c])),_:1})])),_:1})])),_:1})])};export{u as default};
