
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as l}from"./index.9fbc5cc3.js";import{_ as a}from"./index.c535d87f.js";import{_ as e}from"./plugin-vue_export-helper.5a098b48.js";import{r as i,am as o,l as t,H as d,s,n,J as r,I as u,S as f}from"./vendor.e59ac5d6.js";const p={data:()=>({dialogVisible:!1})},m=f("点击打开 Dialog"),c=u("div",null," 按住我进行拖动 ",-1),g=u("span",null,"这是一段信息",-1),b={class:"dialog-footer"},V=f("取 消"),_=f("确 定");var v=e(p,[["render",function(e,f,p,v,x,j){const k=l,y=i("el-button"),C=i("el-dialog"),h=a,w=o("drag");return t(),d("div",null,[s(k,{title:"可拖动对话框"}),s(h,null,{default:n((()=>[s(y,{type:"text",onClick:f[0]||(f[0]=l=>x.dialogVisible=!0)},{default:n((()=>[m])),_:1}),r(u("div",null,[s(C,{modelValue:x.dialogVisible,"onUpdate:modelValue":f[3]||(f[3]=l=>x.dialogVisible=l),width:"30%"},{title:n((()=>[c])),footer:n((()=>[u("span",b,[s(y,{onClick:f[1]||(f[1]=l=>x.dialogVisible=!1)},{default:n((()=>[V])),_:1}),s(y,{type:"primary",onClick:f[2]||(f[2]=l=>x.dialogVisible=!1)},{default:n((()=>[_])),_:1})])])),default:n((()=>[g])),_:1},8,["modelValue"])],512),[[w]])])),_:1})])}]]);export{v as default};
