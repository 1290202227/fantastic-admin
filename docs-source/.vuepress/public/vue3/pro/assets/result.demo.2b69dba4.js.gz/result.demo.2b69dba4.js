
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as e}from"./index.d7acb132.js";import{_ as t}from"./index.eb03be3a.js";import{_ as l}from"./index.6d456c03.js";import{_ as s}from"./plugin-vue_export-helper.5a098b48.js";import{r as a,l as r,H as i,s as d,n,S as u,I as o}from"./vendor.1e0be253.js";const f={},m=u("返回列表"),p=u("打印"),_=o("div",null,"您提交的内容有如下错误：",-1),c=o("div",null,[u(" 您的账户已被冻结 "),o("a",{href:"###"},"打印")],-1),b=u("返回修改");var v=s(f,[["render",function(s,u){const o=e,f=a("el-button"),v=t,x=l;return r(),i("div",null,[d(o,{title:"处理结果",content:"Result"}),d(x,null,{default:n((()=>[d(v,{type:"success",title:"提交成功",desc:"提交结果页用于反馈一系列操作任务的处理结果。"},{default:n((()=>[d(f,{type:"primary",size:"small"},{default:n((()=>[m])),_:1}),d(f,{size:"small"},{default:n((()=>[p])),_:1})])),_:1})])),_:1}),d(x,null,{default:n((()=>[d(v,{type:"error",title:"提交失败",desc:"灰色额外区域可以显示一些补充的信息。请核对并修改以下信息后，再重新提交。"},{extra:n((()=>[_,c])),default:n((()=>[d(f,{type:"primary",size:"small"},{default:n((()=>[b])),_:1})])),_:1})])),_:1})])}]]);export{v as default};
