
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as c}from"./index.ba382bc1.js";import{_ as i}from"./index.8e3c05d1.js";import{_ as d}from"./plugin-vue_export-helper.5a098b48.js";import{l as p,I as l,s as _,n as s,O as r,P as m,J as t}from"./vendor.1c754356.js";const u={},e=o=>(r("data-v-1dd87dc4"),o=o(),m(),o),f=e(()=>t("p",null,"\u81EA\u5B9A\u4E49\u5B57\u4F53\u9700\u8981\u4E0B\u8F7D\u5B57\u4F53\u6587\u4EF6\uFF0C\u4E0D\u5EFA\u8BAE\u5728\u975E\u82F1\u6587\u73AF\u5883\u4E2D\u4F7F\u7528",-1)),g=e(()=>t("p",{style:{"margin-bottom":"0"}},"\u4EE5\u4E0B\u4E3A\u6846\u67B6\u9884\u8BBE\u5B57\u4F53",-1)),h=e(()=>t("p",{class:"digital-7"},"Fantastic-admin",-1)),v=e(()=>t("p",{class:"digital-7"},"1234567890,.",-1)),x=e(()=>t("p",{class:"digital-7_mono"},"Fantastic-admin",-1)),I=e(()=>t("p",{class:"digital-7_mono"},"1234567890,.",-1));function b(o,j){const n=c,a=i;return p(),l("div",null,[_(n,{title:"\u81EA\u5B9A\u4E49\u5B57\u4F53"},{content:s(()=>[f,g]),_:1}),_(a,{title:"Digital 7"},{default:s(()=>[h,v]),_:1}),_(a,{title:"Digital 7\uFF08\u7B49\u5BBD\uFF09"},{default:s(()=>[x,I]),_:1})])}var w=d(u,[["render",b],["__scopeId","data-v-1dd87dc4"]]);export{w as default};
