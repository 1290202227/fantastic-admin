
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a}from"./index.5a1a2157.js";import{_ as e}from"./plugin-vue_export-helper.5a098b48.js";import{r,l as t,m as o,n as s,S as n,P as d,I as i,L as l,Z as p}from"./vendor.e59ac5d6.js";const c={class:"num"},u={class:"tip"};var m=e({props:{colorFrom:{type:String,default:"#843cf6"},colorTo:{type:String,default:"#759bff"},header:{type:String,default:""},num:{type:Number,default:0},tip:{type:String,default:""},icon:{type:String,default:""}},setup:e=>(m,f)=>{const g=a,y=r("el-card");return t(),o(y,{shadow:"hover",class:"mini-card",style:p({background:`linear-gradient(50deg, ${e.colorFrom}, ${e.colorTo})`})},{header:s((()=>[n(d(e.header),1)])),default:s((()=>[i("div",c,d(e.num),1),i("div",u,d(e.tip),1),e.icon?(t(),o(g,{key:0,name:e.icon,rotate:20},null,8,["name"])):l("v-if",!0)])),_:1},8,["style"])}},[["__scopeId","data-v-35c54a03"]]);export{m as _};
