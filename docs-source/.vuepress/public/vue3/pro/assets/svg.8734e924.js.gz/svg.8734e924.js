
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as n}from"./index.d7acb132.js";import{_ as a}from"./index.bf374722.js";import{_ as e}from"./index.6d456c03.js";import{_ as o}from"./plugin-vue_export-helper.5a098b48.js";import{r as i,l as s,H as d,s as l,n as r,S as t}from"./vendor.1e0be253.js";const m={methods:{open(n){window.open(n,"top")}}},g=t("SVG-Loaders 官网");var p=o(m,[["render",function(o,t,m,p,c,f){const u=i("el-button"),_=n,b=a,v=e;return s(),d("div",null,[l(_,{title:"SVG 动画",content:"svg 文件从 SVG-Loaders 中提取，需要注意，svg 均为白色，需要增加底色才能看到效果。如需封装成加载组件，可参考 SpinkitLoading 组件"},{default:r((()=>[l(u,{icon:"el-icon-link",onClick:t[0]||(t[0]=n=>f.open("http://samherbert.net/svg-loaders/"))},{default:r((()=>[g])),_:1})])),_:1}),l(v,{style:{"background-color":"#34495e"}},{default:r((()=>[l(b,{name:"loading-audio"}),l(b,{name:"loading-ball-triangle"}),l(b,{name:"loading-bars"}),l(b,{name:"loading-circles"}),l(b,{name:"loading-grid"}),l(b,{name:"loading-hearts"}),l(b,{name:"loading-oval"}),l(b,{name:"loading-puff"}),l(b,{name:"loading-rings"}),l(b,{name:"loading-spinning-circles"}),l(b,{name:"loading-tail-spin"}),l(b,{name:"loading-three-dots"})])),_:1})])}],["__scopeId","data-v-22e7efe2"]]);export{p as default};
