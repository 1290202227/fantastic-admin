
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a}from"./index.9fbc5cc3.js";import{_ as t}from"./index.c535d87f.js";import{_ as s}from"./plugin-vue_export-helper.5a098b48.js";import{l as i,H as l,s as n,n as o,M as d,O as e,I as r}from"./vendor.e59ac5d6.js";const c={},p=a=>(d("data-v-2850d77a"),a=a(),e(),a),m=p((()=>r("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),_=p((()=>r("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),f=p((()=>r("p",{class:"digital-7"},"Fantastic-admin",-1))),u=p((()=>r("p",{class:"digital-7"},"1234567890,.",-1))),g=p((()=>r("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),v=p((()=>r("p",{class:"digital-7_mono"},"1234567890,.",-1)));var j=s(c,[["render",function(s,d){const e=a,r=t;return i(),l("div",null,[n(e,{title:"自定义字体"},{content:o((()=>[m,_])),_:1}),n(r,{title:"Digital 7"},{default:o((()=>[f,u])),_:1}),n(r,{title:"Digital 7（等宽）"},{default:o((()=>[g,v])),_:1})])}],["__scopeId","data-v-2850d77a"]]);export{j as default};
