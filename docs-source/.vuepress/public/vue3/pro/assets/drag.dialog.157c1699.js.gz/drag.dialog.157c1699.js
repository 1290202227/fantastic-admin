
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as c}from"./index.19b0f213.js";import{_ as m}from"./index.d01cde30.js";import{_ as f}from"./index.7ec46dd3.js";import{A as a,ay as g,j as v,D as t,C as o,o as V,V as b,k as s,$ as d}from"./vendor.9a04353b.js";const x={data(){return{dialogVisible:!1}}},k=d("\u70B9\u51FB\u6253\u5F00 Dialog"),C=s("div",null," \u6309\u4F4F\u6211\u8FDB\u884C\u62D6\u52A8 ",-1),j=s("span",null,"\u8FD9\u662F\u4E00\u6BB5\u4FE1\u606F",-1),y={class:"dialog-footer"},D=d("\u53D6 \u6D88"),$=d("\u786E \u5B9A");function h(w,e,B,N,n,A){const _=m,l=a("el-button"),r=a("el-dialog"),p=c,u=g("drag");return V(),v("div",null,[t(_,{title:"\u53EF\u62D6\u52A8\u5BF9\u8BDD\u6846"}),t(p,null,{default:o(()=>[t(l,{type:"text",onClick:e[0]||(e[0]=i=>n.dialogVisible=!0)},{default:o(()=>[k]),_:1}),b(s("div",null,[t(r,{modelValue:n.dialogVisible,"onUpdate:modelValue":e[3]||(e[3]=i=>n.dialogVisible=i),width:"30%"},{title:o(()=>[C]),footer:o(()=>[s("span",y,[t(l,{onClick:e[1]||(e[1]=i=>n.dialogVisible=!1)},{default:o(()=>[D]),_:1}),t(l,{type:"primary",onClick:e[2]||(e[2]=i=>n.dialogVisible=!1)},{default:o(()=>[$]),_:1})])]),default:o(()=>[j]),_:1},8,["modelValue"])],512),[[u]])]),_:1})])}var z=f(x,[["render",h]]);export{z as default};
