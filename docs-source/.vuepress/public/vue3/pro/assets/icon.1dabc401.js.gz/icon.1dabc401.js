
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as g}from"./index.ec04b431.js";import{_ as b}from"./index.afb4da48.js";import{_ as j}from"./index.4b1af9fd.js";import y from"./alert.5ce33596.js";import{r as o,m as c,Q as a,t as e,q as n,s as t,an as k,a3 as E,a2 as I,Y as $,J as B}from"./vendor.2da94371.js";import{h as r}from"./index.0dc2fa6b.js";import{_ as C}from"./plugin-vue_export-helper.5a098b48.js";const N=$(" \u641C\u7D22 "),V={setup(q){const i=Object.keys(B);return(w,A)=>{const p=j,m=o("el-icon-edit"),_=o("el-icon"),d=o("el-icon-share"),u=o("el-icon-delete"),f=o("el-button"),s=b,h=g,v=o("el-tooltip");return c(),a("div",null,[e(y),e(p,{title:"\u56FE\u6807"}),e(s,{class:"demo"},{default:n(()=>[e(_,null,{default:n(()=>[e(m)]),_:1}),e(_,null,{default:n(()=>[e(d)]),_:1}),e(_,null,{default:n(()=>[e(u)]),_:1}),e(f,{type:"primary",icon:t(k)},{default:n(()=>[N]),_:1},8,["icon"])]),_:1}),e(s,{title:"\u56FE\u6807\u96C6\u5408"},{default:n(()=>[(c(!0),a(E,null,I(t(i),(l,x)=>(c(),a("div",{key:x,class:"list-icon"},[e(v,{class:"item",effect:"dark",content:t(r)(`ElIcon${l}`),placement:"top"},{default:n(()=>[e(h,{name:t(r)(`ElIcon${l}`)},null,8,["name"])]),_:2},1032,["content"])]))),128))]),_:1})])}}};var Y=C(V,[["__scopeId","data-v-647aef8f"]]);export{Y as default};
