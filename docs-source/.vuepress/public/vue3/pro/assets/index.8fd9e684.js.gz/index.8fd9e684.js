
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as s}from"./index.9fbc5cc3.js";import{_ as o}from"./index.c535d87f.js";import{_ as e}from"./plugin-vue_export-helper.5a098b48.js";import{r as t,l as a,H as l,s as n,n as r,I as c,S as d}from"./vendor.e59ac5d6.js";const i={methods:{close(){this.$tabbar.close("/dashboard")}}},u=c("p",null,"访问侧边栏导航里的任意路由，都会在标签栏里自动创建一个标签。",-1),f=c("p",null,"除了在标签栏里操作关闭标签，你也可以使用全局方法关闭当前页面的标签。但如果当前只有一个标签时，则无法关闭。",-1),p=d("关闭当前标签页");var m=e(i,[["render",function(e,c,d,i,m,b){const _=s,h=t("el-button"),j=o;return a(),l("div",null,[n(_,{title:"标签栏",content:"功能类似于浏览器的标签栏，支持右键操作"}),n(j,null,{default:r((()=>[u,f,n(h,{onClick:b.close},{default:r((()=>[p])),_:1},8,["onClick"])])),_:1})])}]]);export{m as default};
