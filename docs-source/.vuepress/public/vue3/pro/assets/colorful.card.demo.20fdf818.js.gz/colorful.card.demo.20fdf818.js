
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as o}from"./index.281722fb.js";import{_ as e}from"./index.2f9397c2.js";import{_ as n}from"./index.46bcf552.js";import{r,n as t,J as d,q as f,l as a}from"./vendor.3dac1dfd.js";import"./index.122b6189.js";const c={};c.render=function(c,i){const l=o,m=e,u=r("el-col"),s=r("el-row"),p=n;return t(),d("div",null,[f(l,{title:"多彩渐变卡片",content:"ColorfulCard"}),f(p,null,{default:a((()=>[f(s,{gutter:20},{default:a((()=>[f(u,{md:6},{default:a((()=>[f(m,{header:"开发文档",num:123,tip:"较上周上升50%",icon:"index-document"})])),_:1}),f(u,{md:6},{default:a((()=>[f(m,{"color-from":"#fbaaa2","color-to":"#fc5286",header:"基础组件",num:12323,tip:"较上周上升50%",icon:"index-component"})])),_:1}),f(u,{md:6},{default:a((()=>[f(m,{"color-from":"#ff763b","color-to":"#ffc480",header:"扩展组件",num:123,tip:"较上周上升50%",icon:"index-component"})])),_:1}),f(u,{md:6},{default:a((()=>[f(m,{"color-from":"#6a8eff","color-to":"#0e4cfd",header:"业务应用页面",num:123,tip:"较上周上升50%",icon:"index-page"})])),_:1})])),_:1})])),_:1})])};export{c as default};
