
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as e}from"./index.9fbc5cc3.js";import{_ as t}from"./index.5df7f292.js";import{_ as l}from"./index.c535d87f.js";import{_ as s}from"./plugin-vue_export-helper.5a098b48.js";import{r as a,l as r,H as d,s as i,n,S as u,I as f}from"./vendor.e59ac5d6.js";const o={},m=u("返回列表"),p=u("打印"),c=f("div",null,"您提交的内容有如下错误：",-1),_=f("div",null,[u(" 您的账户已被冻结 "),f("a",{href:"###"},"打印")],-1),v=u("返回修改");var x=s(o,[["render",function(s,u){const f=e,o=a("el-button"),x=t,y=l;return r(),d("div",null,[i(f,{title:"处理结果",content:"Result"}),i(y,null,{default:n((()=>[i(x,{type:"success",title:"提交成功",desc:"提交结果页用于反馈一系列操作任务的处理结果。"},{default:n((()=>[i(o,{type:"primary",size:"small"},{default:n((()=>[m])),_:1}),i(o,{size:"small"},{default:n((()=>[p])),_:1})])),_:1})])),_:1}),i(y,null,{default:n((()=>[i(x,{type:"error",title:"提交失败",desc:"灰色额外区域可以显示一些补充的信息。请核对并修改以下信息后，再重新提交。"},{extra:n((()=>[c,_])),default:n((()=>[i(o,{type:"primary",size:"small"},{default:n((()=>[v])),_:1})])),_:1})])),_:1})])}]]);export{x as default};
