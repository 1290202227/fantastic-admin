
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as e}from"./index.ffbd20e5.js";import{_ as t}from"./index.f03e52fd.js";import{i as l}from"./logo.3c3b2e9b.js";import{r as a,l as n,J as s,s as d,n as i,R as r,K as f}from"./vendor.7707186e.js";const o={},u=r(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),m=r(" 这里放页面内容 "),p=r(" 还可以结合 ElRow 使用 "),_=r(" 这里放页面内容 "),g=r(" 这里放页面内容 "),c=f("h1",null,"Fantastic-admin",-1),x=f("img",{src:l},null,-1),j=f("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);o.render=function(l,r){const f=e,o=t,y=a("el-col"),b=a("el-row");return n(),s("div",null,[d(f,{title:"内容块",content:"PageMain"}),d(o,null,{default:i((()=>[u])),_:1}),d(o,{title:"你可以设置一个自定义的标题"},{default:i((()=>[m])),_:1}),d(b,{gutter:20,style:{margin:"-10px 10px"}},{default:i((()=>[d(y,{md:8},{default:i((()=>[d(o,{style:{margin:"10px 0"}},{default:i((()=>[p])),_:1})])),_:1}),d(y,{md:8},{default:i((()=>[d(o,{style:{margin:"10px 0"}},{default:i((()=>[_])),_:1})])),_:1}),d(y,{md:8},{default:i((()=>[d(o,{style:{margin:"10px 0"}},{default:i((()=>[g])),_:1})])),_:1})])),_:1}),d(o,{title:"带展开功能",collaspe:"",height:"200px"},{default:i((()=>[c,x,j])),_:1})])};export{o as default};
