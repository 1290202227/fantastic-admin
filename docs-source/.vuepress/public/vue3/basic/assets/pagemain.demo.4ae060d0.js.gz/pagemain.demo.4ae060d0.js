
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a}from"./index.afd122f8.js";import{_ as t}from"./index.2f66b5c7.js";import{_ as e}from"./logo.96f1da49.js";import{_ as l}from"./plugin-vue_export-helper.5a098b48.js";import{r,a as n,n as s,t as d,x as i,F as o,q as f}from"./vendor.8d92a282.js";const u={},m=o(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),p=o(" 这里放页面内容 "),_=o(" 还可以结合 ElRow 使用 "),g=o(" 这里放页面内容 "),x=o(" 这里放页面内容 "),c=f("h1",null,"Fantastic-admin",-1),j=f("img",{src:e},null,-1),h=f("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);var v=l(u,[["render",function(e,l){const o=a,f=t,u=r("el-col"),v=r("el-row");return n(),s("div",null,[d(o,{title:"内容块",content:"PageMain"}),d(f,null,{default:i((()=>[m])),_:1}),d(f,{title:"你可以设置一个自定义的标题"},{default:i((()=>[p])),_:1}),d(v,{gutter:20,style:{margin:"-10px 10px"}},{default:i((()=>[d(u,{md:8},{default:i((()=>[d(f,{style:{margin:"10px 0"}},{default:i((()=>[_])),_:1})])),_:1}),d(u,{md:8},{default:i((()=>[d(f,{style:{margin:"10px 0"}},{default:i((()=>[g])),_:1})])),_:1}),d(u,{md:8},{default:i((()=>[d(f,{style:{margin:"10px 0"}},{default:i((()=>[x])),_:1})])),_:1})])),_:1}),d(f,{title:"带展开功能",collaspe:"",height:"200px"},{default:i((()=>[c,j,h])),_:1})])}]]);export{v as default};
