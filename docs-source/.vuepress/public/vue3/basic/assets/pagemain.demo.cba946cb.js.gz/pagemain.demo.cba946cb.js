
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as t}from"./index.d0cc88c3.js";import{_ as a}from"./index.34d43001.js";import{_ as l}from"./logo.96f1da49.js";import{r as e,a as s,s as d,y as n,z as r,F as i,t as o}from"./vendor.ebf75cd4.js";const u={},f=i(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),m=i(" 这里放页面内容 "),p=i(" 还可以结合 ElRow 使用 "),_=i(" 这里放页面内容 "),c=i(" 这里放页面内容 "),g=o("h1",null,"Fantastic-admin",-1),x=o("img",{src:l},null,-1),y=o("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);u.render=function(l,i){const o=t,u=a,j=e("el-col"),h=e("el-row");return s(),d("div",null,[n(o,{title:"内容块",content:"PageMain"}),n(u,null,{default:r((()=>[f])),_:1}),n(u,{title:"你可以设置一个自定义的标题"},{default:r((()=>[m])),_:1}),n(h,{gutter:20,style:{margin:"-10px 10px"}},{default:r((()=>[n(j,{md:8},{default:r((()=>[n(u,{style:{margin:"10px 0"}},{default:r((()=>[p])),_:1})])),_:1}),n(j,{md:8},{default:r((()=>[n(u,{style:{margin:"10px 0"}},{default:r((()=>[_])),_:1})])),_:1}),n(j,{md:8},{default:r((()=>[n(u,{style:{margin:"10px 0"}},{default:r((()=>[c])),_:1})])),_:1})])),_:1}),n(u,{title:"带展开功能",collaspe:"",height:"200px"},{default:r((()=>[g,x,y])),_:1})])};export{u as default};
