
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as t}from"./index.407496b8.js";import{_ as a}from"./index.fb938e69.js";import{_ as e}from"./logo.96f1da49.js";import{r as l,a as s,s as n,y as r,z as d,F as i,t as o}from"./vendor.505a4e11.js";const u={},f=i(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),m=i(" 这里放页面内容 "),p=i(" 还可以结合 ElRow 使用 "),_=i(" 这里放页面内容 "),g=i(" 这里放页面内容 "),x=o("h1",null,"Fantastic-admin",-1),c=o("img",{src:e},null,-1),y=o("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);u.render=function(e,i){const o=t,u=a,j=l("el-col"),h=l("el-row");return s(),n("div",null,[r(o,{title:"内容块",content:"PageMain"}),r(u,null,{default:d((()=>[f])),_:1}),r(u,{title:"你可以设置一个自定义的标题"},{default:d((()=>[m])),_:1}),r(h,{gutter:20,style:{margin:"-10px 10px"}},{default:d((()=>[r(j,{md:8},{default:d((()=>[r(u,{style:{margin:"10px 0"}},{default:d((()=>[p])),_:1})])),_:1}),r(j,{md:8},{default:d((()=>[r(u,{style:{margin:"10px 0"}},{default:d((()=>[_])),_:1})])),_:1}),r(j,{md:8},{default:d((()=>[r(u,{style:{margin:"10px 0"}},{default:d((()=>[g])),_:1})])),_:1})])),_:1}),r(u,{title:"带展开功能",collaspe:"",height:"200px"},{default:d((()=>[x,c,y])),_:1})])};export{u as default};
