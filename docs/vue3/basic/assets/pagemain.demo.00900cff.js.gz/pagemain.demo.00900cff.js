
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as e}from"./index.1ee7394a.js";import{_ as t}from"./index.e2b18078.js";import{_ as a}from"./logo.96f1da49.js";import{r as l,k as n,n as s,q as r,o as d,A as i,l as o}from"./vendor.e2e92bee.js";const u={},f=i(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),m=i(" 这里放页面内容 "),p=i(" 还可以结合 ElRow 使用 "),_=i(" 这里放页面内容 "),g=i(" 这里放页面内容 "),x=o("h1",null,"Fantastic-admin",-1),c=o("img",{src:a},null,-1),j=o("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);u.render=function(a,i){const o=e,u=t,y=l("el-col"),h=l("el-row");return d(),n("div",null,[s(o,{title:"内容块",content:"PageMain"}),s(u,null,{default:r((()=>[f])),_:1}),s(u,{title:"你可以设置一个自定义的标题"},{default:r((()=>[m])),_:1}),s(h,{gutter:20,style:{margin:"-10px 10px"}},{default:r((()=>[s(y,{md:8},{default:r((()=>[s(u,{style:{margin:"10px 0"}},{default:r((()=>[p])),_:1})])),_:1}),s(y,{md:8},{default:r((()=>[s(u,{style:{margin:"10px 0"}},{default:r((()=>[_])),_:1})])),_:1}),s(y,{md:8},{default:r((()=>[s(u,{style:{margin:"10px 0"}},{default:r((()=>[g])),_:1})])),_:1})])),_:1}),s(u,{title:"带展开功能",collaspe:"",height:"200px"},{default:r((()=>[x,c,j])),_:1})])};export{u as default};
