
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as t}from"./index.0c00e5b3.js";import{_ as a}from"./index.3fc04fb2.js";import{_ as e}from"./logo.96f1da49.js";import{_ as l}from"./plugin-vue_export-helper.5a098b48.js";import{r,a as n,n as s,t as i,x as o,G as d,q as u}from"./vendor.e08917c3.js";const f={},m=d(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),p=d(" 这里放页面内容 "),_=d(" 还可以结合 ElRow 使用 "),c=d(" 这里放页面内容 "),g=d(" 这里放页面内容 "),x=u("h1",null,"Fantastic-admin",-1),j=u("img",{src:e},null,-1),h=u("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);var v=l(f,[["render",function(e,l){const d=t,u=a,f=r("el-col"),v=r("el-row");return n(),s("div",null,[i(d,{title:"内容块",content:"PageMain"}),i(u,null,{default:o((()=>[m])),_:1}),i(u,{title:"你可以设置一个自定义的标题"},{default:o((()=>[p])),_:1}),i(v,{gutter:20,style:{margin:"-10px 10px"}},{default:o((()=>[i(f,{md:8},{default:o((()=>[i(u,{style:{margin:"10px 0"}},{default:o((()=>[_])),_:1})])),_:1}),i(f,{md:8},{default:o((()=>[i(u,{style:{margin:"10px 0"}},{default:o((()=>[c])),_:1})])),_:1}),i(f,{md:8},{default:o((()=>[i(u,{style:{margin:"10px 0"}},{default:o((()=>[g])),_:1})])),_:1})])),_:1}),i(u,{title:"带展开功能",collaspe:"",height:"200px"},{default:o((()=>[x,j,h])),_:1})])}]]);export{v as default};
