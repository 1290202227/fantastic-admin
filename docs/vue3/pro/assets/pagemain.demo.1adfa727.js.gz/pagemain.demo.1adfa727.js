
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as e}from"./index.9fbc5cc3.js";import{_ as t}from"./index.c535d87f.js";import{i as a}from"./logo.3c3b2e9b.js";import{_ as l}from"./plugin-vue_export-helper.5a098b48.js";import{r,l as s,H as n,s as i,n as o,S as d,I as u}from"./vendor.e59ac5d6.js";const f={},m=d(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),p=d(" 这里放页面内容 "),c=d(" 还可以结合 ElRow 使用 "),_=d(" 这里放页面内容 "),g=d(" 这里放页面内容 "),x=u("h1",null,"Fantastic-admin",-1),j=u("img",{src:a},null,-1),b=u("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);var h=l(f,[["render",function(a,l){const d=e,u=t,f=r("el-col"),h=r("el-row");return s(),n("div",null,[i(d,{title:"内容块",content:"PageMain"}),i(u,null,{default:o((()=>[m])),_:1}),i(u,{title:"你可以设置一个自定义的标题"},{default:o((()=>[p])),_:1}),i(h,{gutter:20,style:{margin:"-10px 10px"}},{default:o((()=>[i(f,{md:8},{default:o((()=>[i(u,{style:{margin:"10px 0"}},{default:o((()=>[c])),_:1})])),_:1}),i(f,{md:8},{default:o((()=>[i(u,{style:{margin:"10px 0"}},{default:o((()=>[_])),_:1})])),_:1}),i(f,{md:8},{default:o((()=>[i(u,{style:{margin:"10px 0"}},{default:o((()=>[g])),_:1})])),_:1})])),_:1}),i(u,{title:"带展开功能",collaspe:"",height:"200px"},{default:o((()=>[x,j,b])),_:1})])}]]);export{h as default};
