
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as t}from"./index.c1f75aed.js";import{_ as a}from"./index.29752973.js";import{i as e}from"./logo.3c3b2e9b.js";import{r as l,o as n,z as s,i,w as r,I as d,A as o}from"./vendor.b5a7373b.js";const u={},f=d(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),m=d(" 这里放页面内容 "),p=d(" 还可以结合 ElRow 使用 "),_=d(" 这里放页面内容 "),c=d(" 这里放页面内容 "),g=o("h1",null,"Fantastic-admin",-1),x=o("img",{src:e},null,-1),b=o("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);u.render=function(e,d){const o=t,u=a,j=l("el-col"),y=l("el-row");return n(),s("div",null,[i(o,{title:"内容块",content:"PageMain"}),i(u,null,{default:r((()=>[f])),_:1}),i(u,{title:"你可以设置一个自定义的标题"},{default:r((()=>[m])),_:1}),i(y,{gutter:20,style:{margin:"-10px 10px"}},{default:r((()=>[i(j,{md:8},{default:r((()=>[i(u,{style:{margin:"10px 0"}},{default:r((()=>[p])),_:1})])),_:1}),i(j,{md:8},{default:r((()=>[i(u,{style:{margin:"10px 0"}},{default:r((()=>[_])),_:1})])),_:1}),i(j,{md:8},{default:r((()=>[i(u,{style:{margin:"10px 0"}},{default:r((()=>[c])),_:1})])),_:1})])),_:1}),i(u,{title:"带展开功能",collaspe:"",height:"200px"},{default:r((()=>[g,x,b])),_:1})])};export{u as default};
