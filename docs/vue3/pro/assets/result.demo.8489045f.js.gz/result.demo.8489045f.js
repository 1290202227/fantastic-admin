
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as e}from"./index.c1f75aed.js";import{_ as t}from"./index.95b2dfb2.js";import{_ as l}from"./index.29752973.js";import{r as s,o as a,z as r,i as d,w as i,I as n,A as u}from"./vendor.b5a7373b.js";const o={},f=n("返回列表"),m=n("打印"),p=u("div",null,"您提交的内容有如下错误：",-1),_=u("div",null,[n(" 您的账户已被冻结 "),u("a",{href:"###"},"打印")],-1),c=n("返回修改");o.render=function(n,u){const o=e,y=s("el-button"),b=t,x=l;return a(),r("div",null,[d(o,{title:"处理结果",content:"Result"}),d(x,null,{default:i((()=>[d(b,{type:"success",title:"提交成功",desc:"提交结果页用于反馈一系列操作任务的处理结果。"},{default:i((()=>[d(y,{type:"primary",size:"small"},{default:i((()=>[f])),_:1}),d(y,{size:"small"},{default:i((()=>[m])),_:1})])),_:1})])),_:1}),d(x,null,{default:i((()=>[d(b,{type:"error",title:"提交失败",desc:"灰色额外区域可以显示一些补充的信息。请核对并修改以下信息后，再重新提交。"},{extra:i((()=>[p,_])),default:i((()=>[d(y,{type:"primary",size:"small"},{default:i((()=>[c])),_:1})])),_:1})])),_:1})])};export{o as default};
