
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as t}from"./index.281722fb.js";import{_ as l}from"./index.46bcf552.js";import{i as a}from"./logo.3c3b2e9b.js";import{r as e,n,J as s,q as d,l as i,R as r,K as o}from"./vendor.3dac1dfd.js";const f={},u=r(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),m=r(" 这里放页面内容 "),p=r(" 还可以结合 ElRow 使用 "),_=r(" 这里放页面内容 "),c=r(" 这里放页面内容 "),g=o("h1",null,"Fantastic-admin",-1),x=o("img",{src:a},null,-1),b=o("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);f.render=function(a,r){const o=t,f=l,j=e("el-col"),y=e("el-row");return n(),s("div",null,[d(o,{title:"内容块",content:"PageMain"}),d(f,null,{default:i((()=>[u])),_:1}),d(f,{title:"你可以设置一个自定义的标题"},{default:i((()=>[m])),_:1}),d(y,{gutter:20,style:{margin:"-10px 10px"}},{default:i((()=>[d(j,{md:8},{default:i((()=>[d(f,{style:{margin:"10px 0"}},{default:i((()=>[p])),_:1})])),_:1}),d(j,{md:8},{default:i((()=>[d(f,{style:{margin:"10px 0"}},{default:i((()=>[_])),_:1})])),_:1}),d(j,{md:8},{default:i((()=>[d(f,{style:{margin:"10px 0"}},{default:i((()=>[c])),_:1})])),_:1})])),_:1}),d(f,{title:"带展开功能",collaspe:"",height:"200px"},{default:i((()=>[g,x,b])),_:1})])};export{f as default};
