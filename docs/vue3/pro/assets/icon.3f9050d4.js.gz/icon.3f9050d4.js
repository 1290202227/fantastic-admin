
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as j}from"./index.453fd9a9.js";import{_ as b}from"./index.3be8bba6.js";import{_ as g}from"./index.dec9a165.js";import y from"./alert.f34dcf1b.js";import{A as o,j as c,D as e,C as n,o as s,u as t,an as k,a4 as E,a3 as I,a0 as $,S as C}from"./vendor.0c4fd540.js";import{h as i}from"./index.0dc2fa6b.js";import{_ as A}from"./index.fd3dd73e.js";const B=$(" \u641C\u7D22 "),N={setup(V){const r=Object.keys(C);return(w,D)=>{const p=g,d=o("el-icon-edit"),_=o("el-icon"),m=o("el-icon-share"),u=o("el-icon-delete"),f=o("el-button"),a=b,x=j,h=o("el-tooltip");return s(),c("div",null,[e(y),e(p,{title:"\u56FE\u6807"}),e(a,{class:"demo"},{default:n(()=>[e(_,null,{default:n(()=>[e(d)]),_:1}),e(_,null,{default:n(()=>[e(m)]),_:1}),e(_,null,{default:n(()=>[e(u)]),_:1}),e(f,{type:"primary",icon:t(k)},{default:n(()=>[B]),_:1},8,["icon"])]),_:1}),e(a,{title:"\u56FE\u6807\u96C6\u5408"},{default:n(()=>[(s(!0),c(E,null,I(t(r),(l,v)=>(s(),c("div",{key:v,class:"list-icon"},[e(h,{class:"item",effect:"dark",content:t(i)(`ElIcon${l}`),placement:"top"},{default:n(()=>[e(x,{name:t(i)(`ElIcon${l}`)},null,8,["name"])]),_:2},1032,["content"])]))),128))]),_:1})])}}};var G=A(N,[["__scopeId","data-v-58969013"]]);export{G as default};
