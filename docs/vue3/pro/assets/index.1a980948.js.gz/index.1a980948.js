
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as p,u,g as k}from"./index.0f7a313d.js";import{o as n,l as r,$ as d,Y as _,k as e,w,y as I,a1 as S,B as i,C as m,D as c,F as $,a2 as B,a3 as D,a4 as L,q as N,H as T}from"./vendor.b17bec21.js";const j={class:"copyright"},R=["href"],V={key:1},E=d(" All Rights Reserved "),F={setup(g){const t=u();return(a,o)=>(n(),r("footer",j,[d(" Copyright \xA9 "+_(e(t).copyrightDates)+" ",1),e(t).copyrightWebsite?(n(),r("a",{key:0,href:e(t).copyrightWebsite,target:"_blank",rel:"noopener"},_(e(t).copyrightCompany)+",",9,R)):(n(),r("span",V,_(e(t).copyrightCompany)+",",1)),E]))}};var H=p(F,[["__scopeId","data-v-482c0b3e"]]);const W={setup(g){const{proxy:t}=T(),a=w(),o=u(),f=I(()=>k()),y=S("generateI18nTitle");function h(s){t.$i18n.locale=s,o.setDefaultLang(s),a.meta.title&&o.setTitle(y(a.meta.i18n,a.meta.title))}return(s,q)=>{const v=i("el-dropdown-item"),x=i("el-dropdown-menu"),b=i("el-dropdown");return e(o).enableI18n?(n(),m(b,{key:0,class:"language-container",size:"default",onCommand:h},{dropdown:c(()=>[$(x,null,{default:c(()=>[(n(!0),r(D,null,B(e(f),(l,C)=>(n(),m(v,{key:C,disabled:e(o).defaultLang===l.name,command:l.name},{default:c(()=>[d(_(l.labelName),1)]),_:2},1032,["disabled","command"]))),128))]),_:1})]),default:c(()=>[L(s.$slots,"default",{},void 0,!0)]),_:3})):N("v-if",!0)}}};var Y=p(W,[["__scopeId","data-v-725945c8"]]);export{Y as _,H as a};
