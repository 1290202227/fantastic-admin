
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as r}from"./index.ac124bbf.js";import{_ as c}from"./index.e7f84b3a.js";import{_ as m}from"./index.a6a9d62e.js";import{A as l,j as p,D as e,C as t,o as d,$ as u,Y as f,k as a}from"./vendor.399b4c48.js";const g={methods:{toggle(){this.$store.state.settings.mainPageMaximizeStatus?this.$mainPageMaximize(!1):this.$mainPageMaximize(!0)}}},x=a("p",null,"\u53EF\u901A\u8FC7\u53CC\u51FB\u6807\u7B7E\u9875\uFF0C\u6216\u5728\u6807\u7B7E\u9875\u4E0A\u53F3\u952E\u5E76\u9009\u62E9\u201C\u6700\u5927\u5316\u201D\u8FDB\u5165\u3002",-1),h=a("p",null,"\u540C\u65F6\u6846\u67B6\u8FD8\u63D0\u4F9B\u5168\u5C40\u51FD\u6570\uFF0C\u53EF\u81EA\u7531\u63A7\u5236\u4E3B\u9875\u9762\u662F\u5426\u6700\u5927\u5316\u3002",-1);function $(n,b,j,k,z,o){const s=c,i=l("el-button"),_=r;return d(),p("div",null,[e(s,{title:"\u4E3B\u9875\u9762\u6700\u5927\u5316",content:"\u6269\u5927\u53EF\u89C6\u8303\u56F4\u548C\u64CD\u4F5C\u533A\u57DF\uFF0C\u80FD\u66F4\u4E13\u6CE8\u4E8E\u4E3B\u9875\u9762\u4E0A\u7684\u64CD\u4F5C"}),e(_,null,{default:t(()=>[x,h,e(i,{onClick:o.toggle},{default:t(()=>[u(f(n.$store.state.settings.mainPageMaximizeStatus?"\u9000\u51FA":"\u5F00\u542F")+"\u6700\u5927\u5316",1)]),_:1},8,["onClick"])]),_:1})])}var B=m(g,[["render",$]]);export{B as default};
