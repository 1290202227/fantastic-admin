
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as i}from"./index.5b1f41b8.js";import{_ as u}from"./index.3f87d51d.js";import{_ as p}from"./index.0d16c6a6.js";import{A as s,j as f,D as e,C as t,o as b,a0 as _}from"./vendor.0c4fd540.js";const g={computed:{enableWatermark:{get:function(){return this.$store.state.settings.enableWatermark},set:function(o){this.$store.commit("settings/updateThemeSetting",{enableWatermark:o})}}}},k=_("\u5F00\u542F"),x=_("\u5173\u95ED");function h(o,a,W,j,v,n){const l=u,r=s("el-radio-button"),d=s("el-radio-group"),m=i;return b(),f("div",null,[e(l,{title:"\u9875\u9762\u6C34\u5370",content:"\u5728\u67D0\u4E9B\u573A\u666F\u4E0B\uFF0C\u4E0D\u5E0C\u671B\u7528\u6237\u5C06\u7CFB\u7EDF\u91CC\u7684\u4FE1\u606F\u968F\u610F\u622A\u56FE\u5E76\u8F6C\u53D1\uFF0C\u8FD9\u65F6\u53EF\u5F00\u542F\u9875\u9762\u6C34\u5370\uFF0C\u4EE5\u51CF\u5C11\u8FD9\u79CD\u60C5\u51B5\u53D1\u751F"}),e(m,{title:"\u53EF\u5728 src\\layout\\components\\Watermark\\index.vue \u6587\u4EF6\u91CC\u5B9A\u5236\u6C34\u5370\u6587\u6848\u5185\u5BB9"},{default:t(()=>[e(d,{modelValue:n.enableWatermark,"onUpdate:modelValue":a[0]||(a[0]=c=>n.enableWatermark=c)},{default:t(()=>[e(r,{label:!0},{default:t(()=>[k]),_:1}),e(r,{label:!1},{default:t(()=>[x]),_:1})]),_:1},8,["modelValue"])]),_:1})])}var B=p(g,[["render",h]]);export{B as default};
