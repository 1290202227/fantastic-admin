
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as e}from"./index.281722fb.js";import{_ as t}from"./index.14602606.js";import{_ as l}from"./index.46bcf552.js";import{r as s,n as a,J as r,q as d,l as i,R as n,K as u}from"./vendor.3dac1dfd.js";const f={},o=n("返回列表"),m=n("打印"),p=u("div",null,"您提交的内容有如下错误：",-1),c=u("div",null,[n(" 您的账户已被冻结 "),u("a",{href:"###"},"打印")],-1),_=n("返回修改");f.render=function(n,u){const f=e,y=s("el-button"),x=t,j=l;return a(),r("div",null,[d(f,{title:"处理结果",content:"Result"}),d(j,null,{default:i((()=>[d(x,{type:"success",title:"提交成功",desc:"提交结果页用于反馈一系列操作任务的处理结果。"},{default:i((()=>[d(y,{type:"primary",size:"small"},{default:i((()=>[o])),_:1}),d(y,{size:"small"},{default:i((()=>[m])),_:1})])),_:1})])),_:1}),d(j,null,{default:i((()=>[d(x,{type:"error",title:"提交失败",desc:"灰色额外区域可以显示一些补充的信息。请核对并修改以下信息后，再重新提交。"},{extra:i((()=>[p,c])),default:i((()=>[d(y,{type:"primary",size:"small"},{default:i((()=>[_])),_:1})])),_:1})])),_:1})])};export{f as default};
