
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as v}from"./index.0d4b7cd6.js";import{_ as j}from"./index.ac124bbf.js";import{_ as g}from"./index.e7f84b3a.js";import y from"./alert.ccbead51.js";import{A as o,j as c,D as e,C as n,o as a,u as t,an as k,a3 as $,a2 as E,$ as I,R as C}from"./vendor.399b4c48.js";import{h as i}from"./index.0dc2fa6b.js";import{_ as A}from"./index.a6a9d62e.js";const B=I(" \u641C\u7D22 "),N={setup(V){const r=Object.keys(C);return(w,D)=>{const p=g,m=o("el-icon-edit"),_=o("el-icon"),d=o("el-icon-share"),u=o("el-icon-delete"),f=o("el-button"),s=j,x=v,b=o("el-tooltip");return a(),c("div",null,[e(y),e(p,{title:"\u56FE\u6807"}),e(s,{class:"demo"},{default:n(()=>[e(_,null,{default:n(()=>[e(m)]),_:1}),e(_,null,{default:n(()=>[e(d)]),_:1}),e(_,null,{default:n(()=>[e(u)]),_:1}),e(f,{type:"primary",icon:t(k)},{default:n(()=>[B]),_:1},8,["icon"])]),_:1}),e(s,{title:"\u56FE\u6807\u96C6\u5408"},{default:n(()=>[(a(!0),c($,null,E(t(r),(l,h)=>(a(),c("div",{key:h,class:"list-icon"},[e(b,{class:"item",effect:"dark",content:t(i)(`ElIcon${l}`),placement:"top"},{default:n(()=>[e(x,{name:t(i)(`ElIcon${l}`)},null,8,["name"])]),_:2},1032,["content"])]))),128))]),_:1})])}}};var z=A(N,[["__scopeId","data-v-647aef8f"]]);export{z as default};
