
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as l}from"./index.83ef838b.js";import{_ as r}from"./index.087d2a64.js";import{_ as c}from"./index.27d09c8d.js";import{_ as p}from"./index.f5876f78.js";import{A as m,j as g,D as n,C as o,o as u,$ as f}from"./vendor.399b4c48.js";const v={methods:{open(a){window.open(a,"top")}}},x=f("SVG-Loaders \u5B98\u7F51");function b(a,t,h,$,j,s){const i=m("el-button"),_=c,e=r,d=l;return u(),g("div",null,[n(_,{title:"SVG \u52A8\u753B",content:"svg \u6587\u4EF6\u4ECE SVG-Loaders \u4E2D\u63D0\u53D6\uFF0C\u9700\u8981\u6CE8\u610F\uFF0Csvg \u5747\u4E3A\u767D\u8272\uFF0C\u9700\u8981\u589E\u52A0\u5E95\u8272\u624D\u80FD\u770B\u5230\u6548\u679C\u3002\u5982\u9700\u5C01\u88C5\u6210\u52A0\u8F7D\u7EC4\u4EF6\uFF0C\u53EF\u53C2\u8003 SpinkitLoading \u7EC4\u4EF6"},{default:o(()=>[n(i,{icon:"el-icon-link",onClick:t[0]||(t[0]=k=>s.open("http://samherbert.net/svg-loaders/"))},{default:o(()=>[x]),_:1})]),_:1}),n(d,{style:{"background-color":"#34495e"}},{default:o(()=>[n(e,{name:"loading-audio"}),n(e,{name:"loading-ball-triangle"}),n(e,{name:"loading-bars"}),n(e,{name:"loading-circles"}),n(e,{name:"loading-grid"}),n(e,{name:"loading-hearts"}),n(e,{name:"loading-oval"}),n(e,{name:"loading-puff"}),n(e,{name:"loading-rings"}),n(e,{name:"loading-spinning-circles"}),n(e,{name:"loading-tail-spin"}),n(e,{name:"loading-three-dots"})]),_:1})])}var G=p(v,[["render",b],["__scopeId","data-v-19eb85d2"]]);export{G as default};
