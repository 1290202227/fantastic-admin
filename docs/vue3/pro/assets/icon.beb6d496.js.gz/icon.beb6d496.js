
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as g}from"./index.183dbc98.js";import{_ as j}from"./index.96603fff.js";import{_ as b}from"./index.d1dc7e72.js";import y from"./alert.e09f7712.js";import{B as o,l as c,F as e,D as n,o as s,k as t,ap as k,a3 as E,a2 as I,$,R as B}from"./vendor.b17bec21.js";import{h as i}from"./index.0dc2fa6b.js";import{_ as C}from"./index.0f7a313d.js";const F=$(" \u641C\u7D22 "),N={setup(V){const r=Object.keys(B);return(w,A)=>{const p=b,m=o("el-icon-edit"),_=o("el-icon"),d=o("el-icon-share"),u=o("el-icon-delete"),f=o("el-button"),l=j,x=g,h=o("el-tooltip");return s(),c("div",null,[e(y),e(p,{title:"\u56FE\u6807"}),e(l,{class:"demo"},{default:n(()=>[e(_,null,{default:n(()=>[e(m)]),_:1}),e(_,null,{default:n(()=>[e(d)]),_:1}),e(_,null,{default:n(()=>[e(u)]),_:1}),e(f,{type:"primary",icon:t(k)},{default:n(()=>[F]),_:1},8,["icon"])]),_:1}),e(l,{title:"\u56FE\u6807\u96C6\u5408"},{default:n(()=>[(s(!0),c(E,null,I(t(r),(a,v)=>(s(),c("div",{key:v,class:"list-icon"},[e(h,{class:"item",effect:"dark",content:t(i)(`ElIcon${a}`),placement:"top"},{default:n(()=>[e(x,{name:t(i)(`ElIcon${a}`)},null,8,["name"])]),_:2},1032,["content"])]))),128))]),_:1})])}}};var G=C(N,[["__scopeId","data-v-58969013"]]);export{G as default};
