
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as r}from"./index.afb4da48.js";import{_ as l}from"./index.ec04b431.js";import{_ as p}from"./index.4b1af9fd.js";import{_ as m}from"./plugin-vue_export-helper.5a098b48.js";import{r as c,m as g,Q as u,t as e,q as o,Y as f}from"./vendor.2da94371.js";const v={methods:{open(a){window.open(a,"top")}}},b=f("SVG-Loaders \u5B98\u7F51");function x(a,t,h,k,$,s){const i=c("el-button"),_=p,n=l,d=r;return g(),u("div",null,[e(_,{title:"SVG \u52A8\u753B",content:"svg \u6587\u4EF6\u4ECE SVG-Loaders \u4E2D\u63D0\u53D6\uFF0C\u9700\u8981\u6CE8\u610F\uFF0Csvg \u5747\u4E3A\u767D\u8272\uFF0C\u9700\u8981\u589E\u52A0\u5E95\u8272\u624D\u80FD\u770B\u5230\u6548\u679C\u3002\u5982\u9700\u5C01\u88C5\u6210\u52A0\u8F7D\u7EC4\u4EF6\uFF0C\u53EF\u53C2\u8003 SpinkitLoading \u7EC4\u4EF6"},{default:o(()=>[e(i,{icon:"el-icon-link",onClick:t[0]||(t[0]=j=>s.open("http://samherbert.net/svg-loaders/"))},{default:o(()=>[b]),_:1})]),_:1}),e(d,{style:{"background-color":"#34495e"}},{default:o(()=>[e(n,{name:"loading-audio"}),e(n,{name:"loading-ball-triangle"}),e(n,{name:"loading-bars"}),e(n,{name:"loading-circles"}),e(n,{name:"loading-grid"}),e(n,{name:"loading-hearts"}),e(n,{name:"loading-oval"}),e(n,{name:"loading-puff"}),e(n,{name:"loading-rings"}),e(n,{name:"loading-spinning-circles"}),e(n,{name:"loading-tail-spin"}),e(n,{name:"loading-three-dots"})]),_:1})])}var G=m(v,[["render",x],["__scopeId","data-v-19eb85d2"]]);export{G as default};
