
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as o}from"./index.d7acb132.js";import{_ as e}from"./index.8daf54f1.js";import{_ as r}from"./index.6d456c03.js";import{_ as t}from"./plugin-vue_export-helper.5a098b48.js";import{r as n,l as d,H as a,s as f,n as i}from"./vendor.1e0be253.js";import"./index.bf374722.js";var l=t({},[["render",function(t,l){const m=o,c=e,u=n("el-col"),s=n("el-row"),p=r;return d(),a("div",null,[f(m,{title:"多彩渐变卡片",content:"ColorfulCard"}),f(p,null,{default:i((()=>[f(s,{gutter:20},{default:i((()=>[f(u,{md:6},{default:i((()=>[f(c,{header:"开发文档",num:123,tip:"较上周上升50%",icon:"index-document"})])),_:1}),f(u,{md:6},{default:i((()=>[f(c,{"color-from":"#fbaaa2","color-to":"#fc5286",header:"基础组件",num:12323,tip:"较上周上升50%",icon:"index-component"})])),_:1}),f(u,{md:6},{default:i((()=>[f(c,{"color-from":"#ff763b","color-to":"#ffc480",header:"扩展组件",num:123,tip:"较上周上升50%",icon:"index-component"})])),_:1}),f(u,{md:6},{default:i((()=>[f(c,{"color-from":"#6a8eff","color-to":"#0e4cfd",header:"业务应用页面",num:123,tip:"较上周上升50%",icon:"index-page"})])),_:1})])),_:1})])),_:1})])}]]);export{l as default};
