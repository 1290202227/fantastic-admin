
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as a}from"./index.ffbd20e5.js";import{_ as n}from"./index.a3c54816.js";import{_ as e}from"./index.f03e52fd.js";import{H as o,I as i,r as d,l as s,J as t,s as l,n as r,R as m}from"./vendor.7707186e.js";const g={methods:{open(a){window.open(a,"top")}}};o("data-v-19eb85d2");const c=m("SVG-Loaders 官网");i(),g.render=function(o,i,m,g,f,p){const u=d("el-button"),b=a,v=n,_=e;return s(),t("div",null,[l(b,{title:"SVG 动画",content:"svg 文件从 SVG-Loaders 中提取，需要注意，svg 均为白色，需要增加底色才能看到效果。如需封装成加载组件，可参考 SpinkitLoading 组件"},{default:r((()=>[l(u,{icon:"el-icon-link",onClick:i[0]||(i[0]=a=>p.open("http://samherbert.net/svg-loaders/"))},{default:r((()=>[c])),_:1})])),_:1}),l(_,{style:{"background-color":"#34495e"}},{default:r((()=>[l(v,{name:"loading-audio"}),l(v,{name:"loading-ball-triangle"}),l(v,{name:"loading-bars"}),l(v,{name:"loading-circles"}),l(v,{name:"loading-grid"}),l(v,{name:"loading-hearts"}),l(v,{name:"loading-oval"}),l(v,{name:"loading-puff"}),l(v,{name:"loading-rings"}),l(v,{name:"loading-spinning-circles"}),l(v,{name:"loading-tail-spin"}),l(v,{name:"loading-three-dots"})])),_:1})])},g.__scopeId="data-v-19eb85d2";export{g as default};
