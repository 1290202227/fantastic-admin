
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as o}from"./index.c1f75aed.js";import{_ as e}from"./index.75dc5708.js";import{_ as r}from"./index.29752973.js";import{r as t,o as d,z as n,i as a,w as f}from"./vendor.b5a7373b.js";import"./index.8d81384c.js";const i={};i.render=function(i,c){const l=o,m=e,u=t("el-col"),s=t("el-row"),p=r;return d(),n("div",null,[a(l,{title:"多彩渐变卡片",content:"ColorfulCard"}),a(p,null,{default:f((()=>[a(s,{gutter:20},{default:f((()=>[a(u,{md:6},{default:f((()=>[a(m,{header:"开发文档",num:123,tip:"较上周上升50%",icon:"index-document"})])),_:1}),a(u,{md:6},{default:f((()=>[a(m,{"color-from":"#fbaaa2","color-to":"#fc5286",header:"基础组件",num:12323,tip:"较上周上升50%",icon:"index-component"})])),_:1}),a(u,{md:6},{default:f((()=>[a(m,{"color-from":"#ff763b","color-to":"#ffc480",header:"扩展组件",num:123,tip:"较上周上升50%",icon:"index-component"})])),_:1}),a(u,{md:6},{default:f((()=>[a(m,{"color-from":"#6a8eff","color-to":"#0e4cfd",header:"业务应用页面",num:123,tip:"较上周上升50%",icon:"index-page"})])),_:1})])),_:1})])),_:1})])};export{i as default};
