
/**
 * name: Fantastic-admin
 * homepage: https://hooray.gitee.io/fantastic-admin/
 */
    
import{_ as a}from"./index.c1f75aed.js";import{_ as n}from"./index.8d81384c.js";import{_ as e}from"./index.29752973.js";import{x as o,y as i,r as d,o as s,z as t,i as l,w as r,I as m}from"./vendor.b5a7373b.js";const g={methods:{open(a){window.open(a,"top")}}};o("data-v-22e7efe2");const c=m("SVG-Loaders 官网");i(),g.render=function(o,i,m,g,p,f){const u=d("el-button"),v=a,_=n,b=e;return s(),t("div",null,[l(v,{title:"SVG 动画",content:"svg 文件从 SVG-Loaders 中提取，需要注意，svg 均为白色，需要增加底色才能看到效果。如需封装成加载组件，可参考 SpinkitLoading 组件"},{default:r((()=>[l(u,{icon:"el-icon-link",onClick:i[0]||(i[0]=a=>f.open("http://samherbert.net/svg-loaders/"))},{default:r((()=>[c])),_:1})])),_:1}),l(b,{style:{"background-color":"#34495e"}},{default:r((()=>[l(_,{name:"loading-audio"}),l(_,{name:"loading-ball-triangle"}),l(_,{name:"loading-bars"}),l(_,{name:"loading-circles"}),l(_,{name:"loading-grid"}),l(_,{name:"loading-hearts"}),l(_,{name:"loading-oval"}),l(_,{name:"loading-puff"}),l(_,{name:"loading-rings"}),l(_,{name:"loading-spinning-circles"}),l(_,{name:"loading-tail-spin"}),l(_,{name:"loading-three-dots"})])),_:1})])},g.__scopeId="data-v-22e7efe2";export{g as default};
