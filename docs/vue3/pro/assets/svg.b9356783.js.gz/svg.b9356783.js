
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as r}from"./index.fb8049a8.js";import{_ as d}from"./index.9085138b.js";import{_ as p}from"./index.573d49c9.js";import{_ as c}from"./plugin-vue_export-helper.5a098b48.js";import{r as m,l as g,L as u,s as n,n as o,X as v}from"./vendor.cb7139c2.js";const f={methods:{open(a){window.open(a,"top")}}},b=v("SVG-Loaders \u5B98\u7F51");function x(a,t,h,k,$,s){const i=m("el-button"),_=p,e=d,l=r;return g(),u("div",null,[n(_,{title:"SVG \u52A8\u753B",content:"svg \u6587\u4EF6\u4ECE SVG-Loaders \u4E2D\u63D0\u53D6\uFF0C\u9700\u8981\u6CE8\u610F\uFF0Csvg \u5747\u4E3A\u767D\u8272\uFF0C\u9700\u8981\u589E\u52A0\u5E95\u8272\u624D\u80FD\u770B\u5230\u6548\u679C\u3002\u5982\u9700\u5C01\u88C5\u6210\u52A0\u8F7D\u7EC4\u4EF6\uFF0C\u53EF\u53C2\u8003 SpinkitLoading \u7EC4\u4EF6"},{default:o(()=>[n(i,{icon:"el-icon-link",onClick:t[0]||(t[0]=j=>s.open("http://samherbert.net/svg-loaders/"))},{default:o(()=>[b]),_:1})]),_:1}),n(l,{style:{"background-color":"#34495e"}},{default:o(()=>[n(e,{name:"loading-audio"}),n(e,{name:"loading-ball-triangle"}),n(e,{name:"loading-bars"}),n(e,{name:"loading-circles"}),n(e,{name:"loading-grid"}),n(e,{name:"loading-hearts"}),n(e,{name:"loading-oval"}),n(e,{name:"loading-puff"}),n(e,{name:"loading-rings"}),n(e,{name:"loading-spinning-circles"}),n(e,{name:"loading-tail-spin"}),n(e,{name:"loading-three-dots"})]),_:1})])}var C=c(f,[["render",x],["__scopeId","data-v-19eb85d2"]]);export{C as default};
