
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as c}from"./index.f44aa6da.js";import{_ as m}from"./index.89419a75.js";import{_ as f}from"./plugin-vue_export-helper.5a098b48.js";import{r as _,ao as g,l as v,J as V,s as t,n as o,L as b,K as s,U as a}from"./vendor.66600095.js";const x={data(){return{dialogVisible:!1}}},k=a("\u70B9\u51FB\u6253\u5F00 Dialog"),C=s("div",null," \u6309\u4F4F\u6211\u8FDB\u884C\u62D6\u52A8 ",-1),h=s("span",null,"\u8FD9\u662F\u4E00\u6BB5\u4FE1\u606F",-1),j={class:"dialog-footer"},w=a("\u53D6 \u6D88"),y=a("\u786E \u5B9A");function B(D,e,N,$,l,U){const r=c,i=_("el-button"),d=_("el-dialog"),p=m,u=g("drag");return v(),V("div",null,[t(r,{title:"\u53EF\u62D6\u52A8\u5BF9\u8BDD\u6846"}),t(p,null,{default:o(()=>[t(i,{type:"text",onClick:e[0]||(e[0]=n=>l.dialogVisible=!0)},{default:o(()=>[k]),_:1}),b(s("div",null,[t(d,{modelValue:l.dialogVisible,"onUpdate:modelValue":e[3]||(e[3]=n=>l.dialogVisible=n),width:"30%"},{title:o(()=>[C]),footer:o(()=>[s("span",j,[t(i,{onClick:e[1]||(e[1]=n=>l.dialogVisible=!1)},{default:o(()=>[w]),_:1}),t(i,{type:"primary",onClick:e[2]||(e[2]=n=>l.dialogVisible=!1)},{default:o(()=>[y]),_:1})])]),default:o(()=>[h]),_:1},8,["modelValue"])],512),[[u]])]),_:1})])}var T=f(x,[["render",B]]);export{T as default};
