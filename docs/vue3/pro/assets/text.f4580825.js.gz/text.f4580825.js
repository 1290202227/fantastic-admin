
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as i}from"./index.96603fff.js";import{_ as l}from"./index.d1dc7e72.js";import{l as d}from"./index.0f7a313d.js";import{B as u,l as p,F as t,D as n,o as m,m as f,Y as x,k as g,$ as s}from"./vendor.b17bec21.js";const h=s("\u5207\u6362"),B=s("\u6E05\u7A7A"),T={setup(b){const e=d();function a(){e.setText(e.text=="\u70ED\u95E8"?"\u4FC3\u9500":"\u70ED\u95E8")}function _(){e.setText()}return(k,j)=>{const c=l,o=u("el-button"),r=i;return m(),p("div",null,[t(c,{title:"\u6587\u5B57\u6807\u8BB0",content:"\u642D\u914D Pinia \u53EF\u5B9E\u73B0\u52A8\u6001\u8BBE\u7F6E\u3002\u8BF7\u63A7\u5236\u6587\u5B57\u5C55\u793A\u957F\u5EA6\uFF0C\u907F\u514D\u5BFC\u822A\u6807\u8BB0\u8986\u76D6\u5BFC\u822A\u6807\u9898"}),t(r,null,{default:n(()=>[f("div",null,"\u5F53\u524D badge \u503C\uFF1A'"+x(g(e).text)+"'",1),t(o,{onClick:a},{default:n(()=>[h]),_:1}),t(o,{onClick:_},{default:n(()=>[B]),_:1})]),_:1})])}}};export{T as default};
