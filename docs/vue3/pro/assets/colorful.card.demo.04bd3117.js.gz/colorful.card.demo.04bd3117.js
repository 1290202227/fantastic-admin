
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as o}from"./index.9fbc5cc3.js";import{_ as e}from"./index.30ac5517.js";import{_ as r}from"./index.c535d87f.js";import{_ as t}from"./plugin-vue_export-helper.5a098b48.js";import{r as a,l as n,H as d,s as f,n as c}from"./vendor.e59ac5d6.js";import"./index.5a1a2157.js";var i=t({},[["render",function(t,i){const l=o,m=e,u=a("el-col"),s=a("el-row"),p=r;return n(),d("div",null,[f(l,{title:"多彩渐变卡片",content:"ColorfulCard"}),f(p,null,{default:c((()=>[f(s,{gutter:20},{default:c((()=>[f(u,{md:6},{default:c((()=>[f(m,{header:"开发文档",num:123,tip:"较上周上升50%",icon:"index-document"})])),_:1}),f(u,{md:6},{default:c((()=>[f(m,{"color-from":"#fbaaa2","color-to":"#fc5286",header:"基础组件",num:12323,tip:"较上周上升50%",icon:"index-component"})])),_:1}),f(u,{md:6},{default:c((()=>[f(m,{"color-from":"#ff763b","color-to":"#ffc480",header:"扩展组件",num:123,tip:"较上周上升50%",icon:"index-component"})])),_:1}),f(u,{md:6},{default:c((()=>[f(m,{"color-from":"#6a8eff","color-to":"#0e4cfd",header:"业务应用页面",num:123,tip:"较上周上升50%",icon:"index-page"})])),_:1})])),_:1})])),_:1})])}]]);export{i as default};
